
public class CylinderDriver 
{
	public static void main(String args[])
	{
		Cylinder x=new Cylinder(); //x=New Object 
		double sa, v; //sa=Surface area v= Volume
		
		sa = x.SurfaceArea();
		v = x.Volume();
		
		System.out.println(x.getRadius());
		System.out.println(x.getHeight());
		System.out.println();
		System.out.println("Surface Area = " + sa);
		System.out.println("Volume = " + v);
	}
}
